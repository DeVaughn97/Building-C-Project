#include "account.h"
#include <iostream>
#include <string>
using namespace std;



const string DEFAULT_PASSWORD = "pizzerias";
const char KEY = '\x09'; // The bit pattern of MASK is 00001001
const int DUMMY_ID = 0;

Account::Account(double openingBalance)
{

	identificationNumber = DUMMY_ID;
	balance = openingBalance;
	this->setPassword("pizzerias");
	return;
}

void Account::deposit(double depositAmount)
{
	return;
}

Account::Account(int accountNumber, double openingBalance)
{
	identificationNumber = accountNumber;
	balance = openingBalance;
	this -> setPassword("pizzerias");
	return;
}

Account::~Account(void)
{ // Destructor method stub
	return;
}

void Account::setPassword(string newPassword)
{	
	codedPassword = codePassword(newPassword);
	return;
}


string Account::codePassword(string password) const
{// Set Account's codedPassword attribute to a coded form of password.
	string temp = password;
	int n = password.length();
	int i;
	// using the exclusive OR with KEY, codes the characters in temp,
	// one character at a time.
	for (i = 0; i <= n-1; i++)
	{
		char p;
		p = password[i];
		// Use binary exclusive or to code the ith charcter in password
		char t = p^KEY;
		temp[i] = t;
	}// endfor
	return temp;
}

int Account::validatePassword(string trialPassword) const
{
	string temp;
	temp = codePassword(trialPassword);
	if (temp == codedPassword) return 1;
	else                       return 0;
}
double Account::retrieveBalance(void) const
{
	return balance;
}

int Account::withdraw(double withdrawalAmount)
{
	double temp;
	int flag;
	temp = balance - withdrawalAmount;
	if (temp >= 0) // Is there enough money to cover the withdrawal
	{
		flag = 1;        // Set flag to 1 to signal acceptance
		balance = temp;  // update balance
	}
	else                 //Not enough funds
	{
		flag = 0;       //Set flag to 0 to signal rejection
	} // end of the two alternative branches of the if-else.
	return flag;
}

int Account::transferFundsTo(Account& targetAccount, double transferAmount)
 {
   double temp;
   temp = balance - transferAmount;
   if (temp >=0)
   {                                  // Enough for the transfer?
	   balance = temp;               // If true then update the balance.
                                    // The next line deposits
                                   // the funds in the target account.
	  targetAccount.deposit(transferAmount);  
	  cout << "Transfer Successful";
	  cout << endl;
      return 1;                  // Return 1 to signal success.
   }   
   else
   {                            // Not enough for transfer.
	   cout << "Transfer Failed";
	   return 0;               // Return 0 for failure.
   }
 }// end method 