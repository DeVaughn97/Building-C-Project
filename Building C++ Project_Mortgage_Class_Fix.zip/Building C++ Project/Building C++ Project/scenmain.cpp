//Filename: scenmain.cpp
//File Description: Scenmain Program
//Creation Date:    2/06/2022
//Last Modified:    2/06/2022
//Author:           DeVaughn (Introduced By Garnett)
#include "scenario.h"
#include <iostream>
#include <string>

//void startup(void); //prototype for the startup function
//void coolDown(void); // prototype for the cooldown function
using namespace std;

void startUp(void) // Function definition for StartUp()
{
	cout << "\n\n**************** STARTING TRIALS ****************************";
		cout << endl;
	return;
}// end StartUp



void coolDown(void) //Function definition for CoolDown()
{
	cout << "\n\n****************** TRIALS COMPLETED **************************";
	return;
}// end CoolDown

int main()
{ 
	double husbandOB, wifeOB, principal, interestRate, limit;
	startUp(); //Function call for Startup.
	Scenario trial1;
	trial1.run(); // Run the first scenario.
	cout << endl << " Enter data for second trial run";
	
	do
	{
		
	cout << endl << " Enter the WifeOB" << endl ;
	cin >> wifeOB;

	cout << endl << " Enter the husbandOB" << endl ;
	cin >> husbandOB;
	

	}while (wifeOB < 0 || husbandOB < 0);

	//double limit;
	do
	{

      cout << endl << " Enter the Limit" << endl ;
      cin >> limit ; //This function is to input the limit could possibly need to be improved

	}while (limit < 0);
//	double principal, interestRate;
	int term;
	do
	{
	 cout << endl << " Enter the Principal" << endl ;
       cin >> principal;

	 cout << endl << " Enter the term" << endl ;
		cin >> term ;

	cout << endl << " Enter the interest rate" << endl ;
		cin	>> interestRate;
	}
	while(principal <= 0 || term <=0
		|| interestRate >= .99 || interestRate <= 0.00);
	cin.ignore(80,'\n');   //Ignore the rest of the line.

	Scenario trial2(wifeOB, husbandOB,
		principal, term, interestRate, limit);
	trial2.run();
	coolDown(); //function call
	  system("pause");
	  return 0;
  
}//end main


