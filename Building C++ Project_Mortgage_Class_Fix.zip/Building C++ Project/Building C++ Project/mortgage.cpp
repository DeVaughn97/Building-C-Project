//Filename:         mmortgage.cpp
//File Description: Method File for Credit Class
//Creation Date:    2/05/2022
//Last Modified:    2/05/2022
//Author:           DeVaughn (Originally by Garnett)

#include "mortgage.h"
#include "CreditCard.h"
#include <iostream>
#include <math.h>
using namespace std;
void Mortgage::makeMonthlyPayment(void)
{
	//This payment is for Cash
   
	//Choosing to keep payment to Principal for now instead of fixed
	
	         //Compute the interest due for the month
	interestDue = monthlyInterestRate * remainingPrincipal;
	         // Compute how much is left to apply to the principal
paymentToPrincipal = monthlyPayment - interestDue;
	         // Decrease the principal by the amount of the
	         //monthly payment after the interest has been paid. 
	remainingPrincipal -= paymentToPrincipal;
	return;

}

int Mortgage:: makeMonthlyPayment(CreditCard& sourceCreditCard)
{
	//This payment is for card
	             //Choosing to keep payment to principal for now instead of fixed
	             // Before doing anything see if sourceCreditCard can
				 //cover the monthlyPayment.
				 //Instantiate a local ok object to capture \the value
				 //returen by the postCharge() message when sent to
				// sourceCreditCard using monthlyPayment for the argument
	//double originalLoan;
   // double remainingPrincipal;			 
	int ok;
	ok = sourceCreditCard.postCharge(monthlyPayment);
	          // Test to see if the postCharge() was accepted
	if (ok == 1)
	{
		     // The following lines are executed if
			 // sourceCreditCard accepts the charge. They are exactly
			//  the same as makeMonthlyPayment() method using cash.
			//  Do you see how to use "this" to replace the following
			 // four lines with one line?
		
		
		interestDue = monthlyInterestRate * remainingPrincipal;
		//Payment to principal causes breakpoint issue due to not being initialized hitting continue with program gets expected result as paymentToPrincipal has no direct value here
		paymentToPrincipal = monthlyPayment - interestDue;
	    remainingPrincipal -= paymentToPrincipal; 
	}
	else
	{
		// Charge is rejected. There's nothing to do.
		cout << "Charge is rejected on the card ";
		cout << endl;

	}
    return ok;
}
	
Mortgage::Mortgage(double principal, double yearlyInterestRate,
	              int lengthOfTermInYears)
{
	
	lengthOfTermInYears = 12;
	originalLoan = principal;
	remainingPrincipal = principal;
	monthlyInterestRate = yearlyInterestRate/12;
	term = lengthOfTermInYears;
	monthlyPayment = this->computeMonthlyPayment();
	return;
}

double Mortgage::originalLoanTotal(void) const
{
	
	 return originalLoan;
}
double Mortgage::interestPaidSoFar(void) const
{
	return remainingPrincipal;
}

double Mortgage::remainingPrincipalTotal(void) const
{
	

	return remainingPrincipal;
}

double Mortgage::rate(void) const
{
	 return monthlyInterestRate;
}

int Mortgage::mortgageTerm(void) const
{
	return term;
}

double Mortgage::monthlyInterest(void) const
{
	return interestDue;
}
double Mortgage::marketValue(void) const
{
	return remainingLoan;
}

double Mortgage::fixedMonthlyPayment(void) const
{
	return monthlyPayment;
}

double Mortgage::computeMonthlyPayment(void)
{   // A stub of course
	//double originalLoan;

	double temp1, temp2, temp3;
	double answer;
	int n = term*12;         // term is the number of years
	temp1 = 1+monthlyInterestRate;
	temp2 = pow(temp1,n);   // Compute the nth power of temp1.
	temp3 = monthlyInterestRate/(temp2-1);
    answer = temp3*temp2*originalLoan;
      return answer;   //	return answer;
}// end computermonthlyPayment

Mortgage::~Mortgage(void)
{ 
	// Destructor method stub
	return;
}

