//Filename:         CreditNew.cpp
//File Description: Method File for Credit Class
//Creation Date:    2/3/2022
//Last Modified:    2/3/2022
//Author:           DeVaughn (Originally by Garnett)

#include "CreditCard.h"
#include <iostream>
#include <algorithm>
#include <time.h> 
#include "date.h"
using namespace std;
int CreditCard::postCharge(double chargeAmount)
{
	int flag;

		if (balance + chargeAmount <= creditLimit)
		{
			flag = 1;
			balance = balance + chargeAmount;
		}
		else
		{
			flag =0;
		}
		return flag;
}

void CreditCard::makePayment(double paymentAmount)
{
	//balance = balance - payment; //line 1
	return;

}

double CreditCard:: currentBalance(void) const
{
  return 0;
}



int isExpired(void)
{
	return 0;
}

void modifyRate(double newRate)
{
	return;
}

CreditCard::CreditCard(double limit)
{
	creditLimit = limit;
	return;
}

CreditCard::CreditCard(void)
{
	creditLimit = 3000.00;
	balance = 900000;
	return;
}

CreditCard::~CreditCard(void)
{ // Destructor method stub
	return;
}
