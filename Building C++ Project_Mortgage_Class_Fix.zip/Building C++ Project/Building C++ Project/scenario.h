// Filename:scenario.h
#pragma once
#ifndef SCENARIO_H
#define SCENARIO_H

#include "CreditCard.h"
#include "mortgage.h"
#include "account.h"
class Scenario
{
public:
	 void run(void);
	 Scenario(double wOB, double hOB,
		 double loan, int term, double rate, double cl);
	Scenario(void); 
	 ~Scenario(void);
private:
	//Data Members
	Account hAccount, wAccount;
	CreditCard jointCard;
	Mortgage homeMortgage;
	// private member functions for internal use by the Scenario factory
	void displayMenu(void);
	void cardTransaction(void);
	void accountTransaction(void);
	void mortgageTransaction(void);
	void displayFinances(void);
	void displayMortgageSchedule(Mortgage homeMortgage);
                    
};

#endif