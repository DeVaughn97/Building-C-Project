// Filename: strmain.cpp


#include <string>
using namespace std;

int main()
{
	

}