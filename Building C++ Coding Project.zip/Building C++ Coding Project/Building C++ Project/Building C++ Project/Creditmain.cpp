//Filename: Creditmain.cpp
//File Description: Credit Program
//Creation Date:    2/03/2022
//Last Modified:    2/03/2022
//Author:           DeVaughn 
/*
#include <iostream>
#include <ctime>
using namespace std;
#include "CreditCard.h"


int main()
{
                
	CreditCard yourCard(1000);
	double myLimit;
	cout << "Enter the Card Limit";
	cout << endl;
	cin >> myLimit;
	CreditCard myCard(myLimit);
	double coatPrice;
	
	cout << "Enter the price of the coat";
	cout << endl;
	cin >> coatPrice;
	int ok;
	ok = yourCard.postCharge(coatPrice);
	if(ok == 1)
	{
		cout << endl;
		cout << "Charge accepted";
	}
	else
	{
		cout << "Charge denied";
		cout << endl;
	}

	cout<< "Current Balance of both Cards";
	cout << endl;
	cout<< myCard.currentBalance() + yourCard.currentBalance();
	cout << endl;
	cout<< " Pay off some of the balance on 1 of the card.";
	cout << endl;
	cout << " Enter the amount->";
	double amountYouArePaying;
	cin>> amountYouArePaying;
	myCard.makePayment(amountYouArePaying);
	system("pause");
	return 0;
}
*/
// end main
