// Filename:mortgage.h

#pragma once
#ifndef MORTGAGE_H
#define MORTGAGE_H
#include "CreditCard.h"
#include "date.h"
class Mortgage
{
public:
	// Modifiers
	      void makeMonthlyPayment(void);
		  int makeMonthlyPayment(CreditCard& sourceCreditCard);
    // Accessors
		  double rate(void) const;
		  // Reutrns the yearly interest rate
		 //double originalLoan(void) const;
		 // double remainingPrincipal(void) const;
		  double fixedMonthlyPayment(void) const;
		  //returns fixed  montly payment.
		  double monthlyInterest(void) const;
		  //Returns the interest due that month.
		  double interestPaidSoFar(void) const;
		  //Accumulates the amount of interest paid.
		  int mortgageTerm(void) const;
		  // Returns the total number of years od the mortgage
		  double marketValue(void) const;
		  Date startDate(void)const;
		  // Returns the starting date of the mortgafe
	//Backbone members
		  double originalLoan;
		  double remainingPrincipal;
		  Mortgage(double principal, double yearlyInterestRate,
		  int lengthOfTermInYears);
		  ~Mortgage(void);
private:
	      
	      double monthlyPayment;
		  double initialLoan;
	      double remainingLoan;
		  
		  double monthlyInterestPayment; // This varies month to month.
		  double totalInterest;        //  Accumulates the interest paid so far.
		  double monthlyInterestRate;
		  int term;
		
		 // double remainingPrincipal;
		  Date startingDate;  // Date the mortgage is constructed.
		  double computeMonthlyPayment(void);
		  static const int DEFAULT_TERM;
		  static const double DEFAULT_LOAN;
		  static const double DEFAULT_RATE;
};

#endif