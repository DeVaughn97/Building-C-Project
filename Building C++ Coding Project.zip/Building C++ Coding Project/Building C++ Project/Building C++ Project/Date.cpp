#include <time.h>
#include <iostream>
#include <string>
#include "date.h"
using namespace std;

Date::Date(void)
{
	
	return;
}

Date::~Date(void)
{ // Destructor method stub
	return;
}
