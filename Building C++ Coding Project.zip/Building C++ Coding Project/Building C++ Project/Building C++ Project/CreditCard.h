// Filename:CreditFile.h
#pragma once
#ifndef CREDITFILE_H
#define CREDITFILE_H
#include <ctime>
#include <iostream>
#include "date.h"
#include <string>



class CreditCard
{
public:
	// Modifiers
	int postCharge(double chargeAmount);
	void makePayment(double paymentAmount);
	void chargeInterest(void);
	     // postcondition: applies interest for overdue payments.
	     // Usually this is daily.
	void modifyLimit(double newLimit);
	     // postcondition: Modifies the cards credit limit
	static void modifyRate(double newRate);
	/* postcondition: Modifies the card's interest rate.
	Since every card has the same interest rate, ModifyRate()
	is static */
	void overDue(void);
	// postcondition: marks the card as being late on payments
// Accesors
	double currentBalance(void) const;
	double marketValue(void) const;
	double financeCharge(void) const;
	/* postcondition: returns how much is owed for finance
	charges including interest on late payments. */

	double availbleCredit(void) const;
	/* postcondition: returns how much credit is still left on
	the card.*/

	Date expirationDate(void) const;
	int isExpired(void) const;
	int isOverdue(void) const;
	CreditCard(double limit);
	CreditCard(void);
	~CreditCard(void);

private:
	double creditLimit;

	/* If a card is late on payments then all of the amount owed is subject to interest payments.*/
	double balance;  // Not subject to finance charge
	double overdueBalance;   // Subject to finance charge 
	double interestDue;  // Interest due on overdue balance.
	int overdue;  // This flag indicates whether or
	              // not the payment is overdue.
	Date expires;
	static double interestRate;  /* Every credit card has the same
								    rate.*/
};
#endif