// Filename:account.h
#pragma once
#ifndef ACCOUNT_H
#define ACCOUNT_H

#include <string>
using namespace std;

class Account
{
public:
     int withdraw(double withdrawalAmount);
	 void deposit(double depositAmount);
	 int transferFundsTo(Account & targetAccount, double transferAmount);
	 void setPassword(string newPassword);

	 /* Precondition:         The newPassword cannot be empty.
	    Postcondition:        The Account is given a password.
	*/
	 void restoreCodedPassword(string cpw);
	 /* Restores cpw as the Account's already coded password
	    that had previously been retrieved by
		a previous RetrieveCodePassword() message.


		*/
	 // Accessors
	 double retrieveBalance(void) const;
	 int retrieveAccountNumber(void) const;
	 int validatePassword(string trialPassword) const;
	/* Postcondition: If the trial password matches the Account's password,
	then 1 is returned, else 0 is returned.
	*/
	 string retrieveCodedPassword(void) const;
	 double marketValue(void) const;
	 Account(void);                      //Initializes the balance to 0
	 Account(double openingBalance);
	 Account(int accountNumber, double openingBalance);
	 ~Account(void);
private:
	double balance;                     //Tracks the current balance
	string codedPassword;
	/* The next private member function is used
	to code the password since we don't want to store uncoded
	passwords. */
	string codePassword(string password) const;
	// Postcondition: Returns the coded form of password.
	int identificationNumber;  // Stores account's number
};

#endif