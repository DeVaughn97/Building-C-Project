//Filename:         logomain.cpp
//File Description: Test Driver File for the Logo Class
//Creation Date:    8/27/2021
//Last Modified:    8/27/2021
//Author:           DeVaughn (Introduced by Garnett)

#include "logo.h"
#include <string>
int main ()
{
	Logo appleLogo;
    appleLogo.display();
    appleLogo.changeLogo();
	appleLogo.display();
	Logo myLogo;
	myLogo.addLogo("*H*E*L*L*O*");       //Line 1
	myLogo.display();                    //Line 2
	myLogo.addLogo("Testing"); //Line 3
	myLogo.display();                    //Line 4
	system("pause");
	return 0;
};