// Filename:            logo.h
// File Description:   Header file for the Logo class
// Creation Date:      8/24/2021
// Last Modified:      8/24/2021
// Author:             Garnett Modified my DeVaughn
#pragma once
#ifndef LOGO_H
#define LOGO_H

#include <string>
using namespace std;

class Logo
{
public:
	void changeLogo(void);
	// precondition: none
	// postcondition: prompts for a new logo input
	// from the keyboard
	void display(void) const;
	// precondition: none
	// postcondition: displays the logo
	// on the standard output device
	Logo(void);
	Logo(string startupLogo);
	// precondition: none
	// postcondition: creates a welcoming Logo object
	~Logo(void);
	// precondition: none
	// postcondition: destroys the logo
	void addLogo(string extraWords);

private:
	string pattern;
}; //end of Logo class declaration
#endif