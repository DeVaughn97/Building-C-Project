//Filename:         logo.cpp
//File Description: Test Driver File for the Logo Class
//Creation Date:    8/27/2021
//Last Modified:    8/27/2021
//Author:           DeVaughn (Originally by Garnett)

#include "logo.h"
#include <string>
#include <iostream>
using namespace std;

const string FACTORY_PATTERN = "*L*O*G*O*";

Logo::Logo(void)
{ // Constructor method stub
	pattern = FACTORY_PATTERN;
	return;
}

Logo::Logo(string startupLogo)
{
	pattern =startupLogo;
	return;
}

Logo::~Logo(void)
{ // Destructor method stub
	return;
}


void Logo::display(void) const
{ // display method stub
	cout << endl;         // Go to a new line.
	cout << pattern;     // show the pattern.
	cout << endl;       // Go to a new line.
	return;
}

void Logo::changeLogo(void)
{
	// changeLogo method stub

	cout << endl;                                // Go to a new line
	cout << "Enter characters for new logo->";  // Prompt for input
	cin  >> pattern;                            // Extract the input.
	return;
}


void Logo::addLogo(string extraWords)
{
	pattern += extraWords;
	return;
}