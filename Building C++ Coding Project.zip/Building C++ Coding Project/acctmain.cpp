//Filename: acctmain.cpp
//File Description: Account Program
//Creation Date:    9/04/2021
//Last Modified:    9/04/2021
//Author:           DeVaughn 
/*
#include "account.h"
#include <iostream>
#include <ctime>
using namespace std;

int main()
{
	Account myAccount;                       //Creates an Account object.
	Account secondAccount, thirdAccount;    // Prompt the user for input.
	                                       // and extract the value from cin.
	cout << "What is the account you are inquiring upon 1 or 2";
	cout << endl;
	cout << "Account 2 tranfser option is enabled";
	cout << endl;
	double accountSelection;
    
	cin>> accountSelection;
    
if(accountSelection == 1)
	{
	
	cout << "Enter the amount of deposit";
	cout << "( Don't use commas or decimal points)  ->";
	double amountEntered;                                     // Line 1
	                      // Extract the amountEntered
	                     //  from the keyboard.
	cin >> amountEntered;
                        // Deposit the amountEntered
	                   // into myAccount.
	myAccount.deposit(amountEntered);
	                  // Prompt the user for input and
					 // extract the value from cin.
	cout << endl;
	cout << "Enter the amount of withdrawal->";
	                  // We can use the same double object
	                  // amountEntered,to receive the input.
	cin >> amountEntered;                                   // Extract the amountEntered
	                  // From the Keyboard.
	                  // Get ready to send the
	                  // withdraw() message to myAccount.
	                  // Instantiate ok to capture returned
	int ok;           // by withdraw().
	ok = myAccount.withdraw(amountEntered);                      //Line 2
	                  // Test the value in ok
	                  // to see whether or not
	                  // the withdrawal was successful

	if (ok == 1)                                                 //Line 3
	{
		 cout << endl;                                           //Line 4
		 cout << "Withdrawal Accepted";
	}
	else
	{
		cout << endl;                                            //Line 5
		cout << "Withdrawal Rejected";
	} //  endif
	                                     //Display the amount
	                                    // of funds in myAccount.

	cout << endl;                                                //Line 6
	cout << "The account has $";
	cout << myAccount.retrieveBalance();
	cout << endl;
	system("pause");
	return 0;
   }
if(accountSelection == 2)
	{
	
	cout << "Enter the amount of deposit";
	cout << "( Don't use commas or decimal points)  ->";
	double amountEntered;                                     // Line 1
	                      // Extract the amountEntered
	                     //  from the keyboard.
	cin >> amountEntered;
                        // Deposit the amountEntered
	                   // into myAccount.
	secondAccount.deposit(amountEntered);
	                  // Prompt the user for input and
					 // extract the value from cin.
	cout << endl;
	cout << "Enter the amount of withdrawal->";
	                  // We can use the same double object
	                  // amountEntered,to receive the input.
	cin >> amountEntered;                                   // Extract the amountEntered
	                  // From the Keyboard.
	                  // Get ready to send the
	                  // withdraw() message to myAccount.
	                  // Instantiate ok to capture returned
	int ok;           // by withdraw().
	ok = secondAccount.withdraw(amountEntered);                      //Line 2
	                  // Test the value in ok
	                  // to see whether or not
	                  // the withdrawal was successful

	if (ok == 1)                                                 //Line 3
	{
		 cout << endl;                                           //Line 4
		 cout << "Withdrawal Accepted";
	}
	else
	{
		cout << endl;                                            //Line 5
		cout << "Withdrawal Rejected";
	} //  endif
	                                     //Display the amount
	                                    // of funds in myAccount.

	cout << endl;                                                //Line 6
	cout << "The account has $";
	cout << secondAccount.retrieveBalance();
	cout << endl;
	double transferAmount;
	cout << "Enter amount to be transferred->";
	cin >> transferAmount;
	int success;
	success = secondAccount.transferFundsTo(thirdAccount, transferAmount); 
	system("pause");
	return 0;
   }
  else
  {
	  cout << "This selection is invalid try later";
	  cout << endl;
	  system("pause");
	  return 0;
  }
} */
// end main