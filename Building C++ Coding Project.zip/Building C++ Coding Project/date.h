// Filename:date.h
#pragma once
#include <time.h>
#include <iostream>
#include <string>
using namespace std;
#ifndef DATE_H
#define DATE_H


class Date
{
public:
	// Assignment operator
	   Date operator = (const Date & d);

	  // Comparision operators. Return 1 for true and 0 for false
	     int operator< (const Date & d);
		 int operator> (const Date & d);
		 int operator== (const Date & d);
		 int operator!= (const Date &d);
      // Arithmetic operators
	  //For the following members the parameter represents the number of days.
		 Date operator+ (int ndays);
		 Date operator- (int ndays);
		 Date operator+= (int ndays);
		 Date operator-= (int ndays);
		 //The next parameter is a date.
		 int operator- (Date d); // d1- d2 is the number of days between d1
		                         // and d2
		 Date(int day, int month, int year);
		 /* Precondition:
		 Use all four digits for entering the year.
		 For example, Date d(23,10, 1999) represents Oct. 10, 1999.
       Postcondition:
	      In case the parameters represent an invalid date, Date uses the
	   Current system date as the initialization value. The constructor is
	   friendly. Date d(31,11,1990) is constructed as Dec. 1, 1990 since
	   November has only 30 days.
	   */
		   
		   Date(void);  //intializes to the current date.

		   ~Date(void);

		   friend ostream & operator<< (ostream& outDevice, Date d);
		   // Precondition: none
		   // Postcondition: Displays d

		   friend istream & operator>> (istream& inDevice, Date & d);
		   /*
		   Precondition:
		      The user keys in three integers separated by blanks. The first
			  integer is between 1 and 31 and represents the day. The second
			  integer is between 1 and 12 and represents a month. The third
			  integer is between 1970 and 1999 and represents the year.
		   Postcondition:
		      If the input doesn't represent a valid date, the d is unchanged.
			*/
private:
};
#endif