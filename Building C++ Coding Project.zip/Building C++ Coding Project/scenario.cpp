//Filename: scenario.cpp
//File Description: scenario cpp Program
//Creation Date:    2/06/2022
//Last Modified:    2/06/2022
//Author:           DeVaughn 
#include "scenario.h"
#include <iostream>
#include <iomanip>
#include <string>
#include "account.h"
#include <stdlib.h>
using namespace std;

const double DEFAULT_CREDIT_LIMIT = 1000;
const double DEFAULT_MORTGAGE = 10000;
const double DEFAULT_RATE = 0.10;
const int DEFAULT_TERM = 10;

Scenario::Scenario(double wOB, double hOB,
		 double loan, int term, double rate, double cl):
// Initialize data members using the constructor arguments.
       wAccount(wOB), hAccount(hOB), jointCard(cl), 
		   homeMortgage(loan, rate, term)
	   {
		   return;
	   }
Scenario::Scenario(void):
	   // Initialize the data members with default values
	   wAccount(20000.0), hAccount(20000.0), jointCard(1000),
	   homeMortgage(10000, 0.10, 10)
	   {
		   return;
	   }

Scenario::~Scenario(void)
{
	return;
}
void Scenario::run(void) 
{
		   string input;
		   char choice;
		   do {
			   displayMenu();
			   cin >> input;
			   choice = input[0];
			   switch (choice)
			   {
			   case 'C': case 'c': cardTransaction(); break;
			   case 'A': case 'a': accountTransaction(); break;
			   case 'M': case 'm': mortgageTransaction(); break;
			   case 'D': case 'd': displayFinances(); break;
			   case 'E': case 'e': break;
			   default : cout << "Error";
					  break;
			   }//end switch
		   }
		   while ( (choice != 'e') && (choice != 'E') );
		   return;
}

void Scenario::displayMenu(void)
{
		   cout << "\n************************ MENU OF CHOICES **************************\n";
		   cout << "\n C\tCredit Card Transaction" << "\n A\tAccount Transaction" << "\n M\tMortgage Transaction" << "\n D\tDisplay Finances";
		   cout << "\n\n*****************************************************************";
		   cout << "\n\n\nEnter your choice and hit the enter key ->";
		   return;
}


void Scenario::cardTransaction(void)
{
		   cout << "\n************************ MENU OF CREDIT CARD CHOICES **************************\n";
		   cout << "\n C\tCredit Card Charge";
		   cout << "\n E\tExit";
		   cout << "\n\n*****************************************************************************";
		   cout << "\n\nEnter your choice and hit the enter key ->";
		   string input;
		   cin >> input;
		   char choice;
		   choice = input[0];
		   switch (choice)
		   {
		   case 'c': case 'C':
			   int flag;
			   double amount;
			   cout << "Enter the Amount:" ;
			   cin >> amount;
			   if (amount < 0 )
			   {
				   flag = 0;
			   }
			   else
			   {
				   flag = jointCard.postCharge(amount);
			   }//endif
			   if (flag == 1)
			   {
				   cout << "\nCharge accepted";
			   }
			   else
			   {
				   cout << endl << "Rejected";
			   }//endif
			   break;
			   case 'p' : case 'P' :
			   break;
			   case'm': case 'M' :
			   case 'e' : case 'E': break;
			   default :
				   cout << endl << " Error";
				   break;
		   }//end switch
		   cout << "\n\n";
		   return;
}

void Scenario::displayFinances(void)
{
			   cout << "\n\n********************* FINANCIAL STATMENT **************************\n";
			   cout.setf(ios::fixed);  // Don't use scientific notation.
			   cout.precision(2);     // Only show two decimal point.

			   cout << "\n DEBITS:";
			   cout << "\n Credit Card Debt    ->$" << jointCard.currentBalance();
			   cout << "\n Current Balance ->$" << hAccount.retrieveBalance();
			    cout << "\n Current Balance ->$" << wAccount.retrieveBalance();
			   return;
}

void Scenario::accountTransaction(void)
{
			cout << "\n************************ MENU OF ACCOUNT TRANSACTIONS **************************\n";
		   cout << "\n T\tAccount Transfer";
		   cout << "\n E\tExit";
		   cout << "\n\n*****************************************************************************";
		   cout << "\n\nEnter your choice and hit the enter key ->";
		   string input;
		   cin >> input;
		   char choice;
		   choice = input[0];
			   switch (choice)
{//Start of Choice Switch ------------------------------------------------------------------------------------------------------------
			    case 'T':
					{
				   int code;
				   double transferAmount;
				   cout <<"\nEnter 1 for transfer FROM wife TO husband.";
				   cout <<"\nEnter 2 for transfer FROM husband TO wife.";
				   cin >> code;
				   cout << "\nEnter the amount of being transferred ->$";
				   cin >> transferAmount;
				 
				  // cin.ignore(80,'n');
				   switch (code)
      {//Start of Code Switch---------------------------------------------------------------------------------------------------------
				   case 1:
		{// Case 1--------------------------------------------------------------------------------
					   //Transfer form wife's account to husband's account
					   string pw;
					   cout << "\nEnter wife's password -> ";
					   cin >> pw;
					   int flag;
			          
					   if (!wAccount.validatePassword(pw))
					   {
						   cout << "\nINVALID PASSWORD";
						   flag = 0;
					   }
					   else
					   {
						   flag = wAccount.transferFundsTo(hAccount, transferAmount);
					   }//endif
					   if (flag == 1)
					   {
						   cout << "\nSuccessful transfer of funds";
					   }
					   else
					   {
						   cout << "\nTransfer of funds rejected.";
					   }//endif
					   break;
		}// Case 1---------------------------------------------------------------------------------
				   case 2:
		 {//Case 2-------------------------------------------------------------------------
					   //Transfer from Husband's account to Wife's account
					   string pw;
					   cout << "\nEnter wife's password -> ";
					   cin >> pw;
					   int flag;
			          
					   if (!hAccount.validatePassword(pw))
					   {
						   cout << "\nINVALID PASSWORD";
						   flag = 0;
					   }
					   else
					   {
						   flag = wAccount.transferFundsTo(wAccount, transferAmount);
					   }//endif
					   if (flag == 1)
					   {
						   cout << "\nSuccessful transfer of funds";
					   }
					   else
					   {
						   cout << "\nTransfer of funds rejected.";
					   }//endif
					   break;
	    }//End of Case 2-----------------------------------------------------------------
				   default:
					   break;
   }// end error message code switch also end of Code Switch -----------------------------------------------------------------------
				   break;
			   }//End of Case T
}//End of Choice Switch-----------------------------------------------------------------------------------------------------------------------------------------------------
			   return;
}

void displayMortgageSchedule(Mortgage m); // Function prototype
void Scenario::mortgageTransaction(void)
{

	       
	       cout << "\n************************ MENU OF MORTGAGE CHOICES **************************\n";
		   cout << "\n D\tDisplay Mortgage Schedule";
		   cout << "\n N\tMake Mortgage Payment";
		   cout << "\n E\tExit";
		   cout << "\n\n*****************************************************************************";
		   cout << "\n\nEnter your choice and hit the enter key ->";
		   string input;
		   cout << endl << "Enter the input";
		   cin >> input;
		   char choice;
		   choice = input[0];
		   switch (choice)
		   {
		   case 'd' :case 'D':
			   displayMortgageSchedule(homeMortgage);
			   break;
		   case 'n' : case 'N':
			   int paymentCode;
			   cout << "\nEnter 1 for cash payment 2 for Credit Card Payment";
			   cin >> paymentCode;
			   if (paymentCode == 1)
			   {
				   homeMortgage.makeMonthlyPayment();
			   }
			   else if ( paymentCode == 2)
			   {
				   int flag;
				   flag =
					   homeMortgage.makeMonthlyPayment(jointCard);
				   if (flag == 0)
				   {
					   cout << "\nCredit Card doesn't not" << "accept charge";
				   }
				   else
				   {
					   cout << "\nCredit Card accepts " << "mortgage payment";
				   }//endif
			   }
			   else
			   {
				   cout << "\nInvalid choice";
			   }// endif
		   case 'e':case 'E' : break;
		   default :
			   cout << "error";
			   break;
		   }//end switch
		   return;
}
void displayMortgageSchedule(Mortgage m)
{
	// First find the original terms of the mortgage.
	double loan = m.originalLoan;
	double InterestRate = m.rate();
	int term = m.mortgageTerm();
	// Next, constuct a copy of the original mortgage.
	Mortgage copy(loan, InterestRate, term);
	//Display Heading
	cout << "*************************** MONTHLY PAYMENT SCHEDULE ******************";
	cout << "\n\nMonth" << "\tPrincipal" << "\t\t Paid";
	cout << "\n________________" << "\t__________________" << "\t\t_______________";
	cout << "\n"; // Skip a line
	// n controls the numebr of payments
	int n = 12*copy.mortgageTerm();
	int month; // month is the loop control variable
	for (month = 0 ; month < n; month++)
	{
		cout << endl << month + 1; // Display the month number
		m.makeMonthlyPayment();//Make a monthly payment
		//format output
		cout << "Success";
		cout << copy.remainingPrincipal;
		cout << "\t\t" << m.monthlyInterest();
	}//endfor
	// Display summary data
	cout <<"\n\n";
	cout << "\n Total Interest Payment is -> $" << m.interestPaidSoFar();
	return;
}



			 